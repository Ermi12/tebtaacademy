import React from 'react';

export default function Footer(){
  return (
    <footer className="footer">
      <div className="container">
        <p>© {new Date().getFullYear()} Tebta Academy. All rights reserved.</p>
      </div>
    </footer>
  );
}

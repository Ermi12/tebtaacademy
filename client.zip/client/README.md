# Client (Vite + React)

Run:

```
cd client
npm install
npm run dev
```

Frontend runs on port 5173 and proxies to server at /api endpoints if you run server separately.
